import type { Metadata, Viewport } from "next"
import { Geist, Geist_Mono } from "next/font/google"
import { Analytics } from "@vercel/analytics/next"
import { ThemeProvider } from "@/components/theme-provider"
import { Toaster } from "@/components/ui/toaster"
import "./globals.css"

const geist = Geist({ subsets: ["latin"], variable: "--font-sans" })
const geistMono = Geist_Mono({ subsets: ["latin"], variable: "--font-mono" })

export const metadata: Metadata = {
  title: "Samuel Lemeneh | Full-Stack Engineer",
  description:
    "Senior Full-Stack Engineer specializing in building production systems that serve real users. Expert in React, Next.js, TypeScript, Node.js, and PostgreSQL.",
  keywords: [
    "Full-Stack Developer",
    "Software Engineer",
    "React Developer",
    "Next.js Developer",
    "TypeScript",
    "Ethiopia",
    "Web Developer",
  ],
  authors: [{ name: "Samuel Lemeneh" }],
  creator: "Samuel Lemeneh",
  openGraph: {
    type: "website",
    locale: "en_US",
    url: "https://samuellemeneh.dev",
    title: "Samuel Lemeneh | Full-Stack Engineer",
    description:
      "Senior Full-Stack Engineer building production systems that serve real users across Ethiopia and beyond.",
    siteName: "Samuel Lemeneh Portfolio",
  },
  twitter: {
    card: "summary_large_image",
    title: "Samuel Lemeneh | Full-Stack Engineer",
    description:
      "Senior Full-Stack Engineer building production systems that serve real users.",
    creator: "@samuellemeneh",
  },
  robots: {
    index: true,
    follow: true,
  },
}

export const viewport: Viewport = {
  themeColor: [
    { media: "(prefers-color-scheme: light)", color: "#f8fafc" },
    { media: "(prefers-color-scheme: dark)", color: "#0f172a" },
  ],
  width: "device-width",
  initialScale: 1,
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" suppressHydrationWarning className="bg-background">
      <body
        className={`${geist.variable} ${geistMono.variable} font-sans antialiased`}
      >
        <ThemeProvider
          attribute="class"
          defaultTheme="system"
          enableSystem
          disableTransitionOnChange
        >
          {children}
          <Toaster />
        </ThemeProvider>
        {process.env.NODE_ENV === "production" && <Analytics />}
      </body>
    </html>
  )
}
