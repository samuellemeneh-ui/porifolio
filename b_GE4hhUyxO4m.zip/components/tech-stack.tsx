"use client"

import { motion } from "framer-motion"
import { Badge } from "@/components/ui/badge"
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip"

const technologies = [
  { name: "React", experience: "5+ years", category: "frontend" },
  { name: "Next.js", experience: "4+ years", category: "frontend" },
  { name: "TypeScript", experience: "4+ years", category: "frontend" },
  { name: "Tailwind CSS", experience: "4+ years", category: "frontend" },
  { name: "Node.js", experience: "5+ years", category: "backend" },
  { name: "Python", experience: "4+ years", category: "backend" },
  { name: "PostgreSQL", experience: "4+ years", category: "database" },
  { name: "Prisma", experience: "3+ years", category: "database" },
  { name: "REST APIs", experience: "5+ years", category: "backend" },
  { name: "WebSockets", experience: "3+ years", category: "backend" },
  { name: "Docker", experience: "3+ years", category: "devops" },
  { name: "Git", experience: "5+ years", category: "devops" },
]

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.05,
    },
  },
}

const itemVariants = {
  hidden: { opacity: 0, scale: 0.8 },
  visible: { opacity: 1, scale: 1 },
}

export function TechStack() {
  return (
    <section className="py-16 sm:py-20 bg-secondary/30">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="text-center mb-12"
        >
          <h2 className="text-3xl sm:text-4xl font-bold text-foreground mb-4">
            Tech Stack
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Technologies I work with daily to build scalable, production-ready
            applications.
          </p>
        </motion.div>

        <TooltipProvider>
          <motion.div
            variants={containerVariants}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            className="flex flex-wrap justify-center gap-3"
          >
            {technologies.map((tech) => (
              <Tooltip key={tech.name}>
                <TooltipTrigger asChild>
                  <motion.div variants={itemVariants}>
                    <Badge
                      variant="secondary"
                      className="px-4 py-2 text-sm font-medium cursor-pointer hover:bg-accent hover:text-accent-foreground transition-all duration-200 hover:scale-105"
                    >
                      {tech.name}
                    </Badge>
                  </motion.div>
                </TooltipTrigger>
                <TooltipContent>
                  <p>{tech.experience}</p>
                </TooltipContent>
              </Tooltip>
            ))}
          </motion.div>
        </TooltipProvider>
      </div>
    </section>
  )
}
