"use client"

import { motion } from "framer-motion"
import { ExternalLink, Github } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card"

const projects = [
  {
    title: "AgroGebeya",
    role: "Lead Full-Stack Developer",
    description:
      "Agricultural retail management platform connecting Ethiopian farmers directly with retailers. Eliminates middlemen, provides real-time inventory and pricing.",
    tech: ["Next.js", "Prisma", "PostgreSQL", "Tailwind", "JWT Auth", "Python"],
    metrics: ["3,200+ farmers", "45% reduced costs", "Real-time sync"],
    demoUrl: "#",
    githubUrl: "#",
  },
  {
    title: "Tana Care",
    role: "Frontend Lead + API Integration",
    description:
      "Telemedicine platform enabling remote consultations, e-prescriptions, and patient record management.",
    tech: ["React", "TypeScript", "WebRTC", "Tailwind", "Node.js", "PostgreSQL"],
    metrics: ["1,500+ consultations", "4.8★ patient rating"],
    demoUrl: "#",
    githubUrl: "#",
  },
  {
    title: "Sabi Car Rental",
    role: "Full-Stack Developer",
    description:
      "Car rental management system with real-time availability, booking engine, and automated payments.",
    tech: ["Next.js", "Prisma", "PostgreSQL", "Mapbox API", "Stripe", "Tailwind"],
    metrics: ["98% booking accuracy", "300+ active rentals"],
    demoUrl: "#",
    githubUrl: "#",
  },
]

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.15,
    },
  },
}

const cardVariants = {
  hidden: { opacity: 0, y: 30 },
  visible: { opacity: 1, y: 0 },
}

export function ProjectsSection() {
  return (
    <section id="projects" className="py-20 sm:py-24">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl sm:text-4xl font-bold text-foreground mb-4">
            Featured Projects
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Production systems serving real users with measurable impact.
          </p>
        </motion.div>

        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          className="grid md:grid-cols-2 lg:grid-cols-3 gap-6"
        >
          {projects.map((project) => (
            <motion.div key={project.title} variants={cardVariants}>
              <Card className="group h-full flex flex-col bg-card border-border hover:border-accent/50 transition-all duration-300 hover:shadow-lg hover:shadow-accent/5 hover:scale-[1.02]">
                <CardHeader className="pb-4">
                  <div className="flex items-start justify-between">
                    <div>
                      <h3 className="text-xl font-semibold text-foreground group-hover:text-accent transition-colors">
                        {project.title}
                      </h3>
                      <p className="text-sm text-accent mt-1">{project.role}</p>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="flex-1 pb-4">
                  <p className="text-muted-foreground text-sm leading-relaxed mb-4">
                    {project.description}
                  </p>

                  <div className="flex flex-wrap gap-2 mb-4">
                    {project.tech.map((tech) => (
                      <Badge
                        key={tech}
                        variant="outline"
                        className="text-xs font-normal"
                      >
                        {tech}
                      </Badge>
                    ))}
                  </div>

                  <div className="flex flex-wrap gap-2">
                    {project.metrics.map((metric) => (
                      <span
                        key={metric}
                        className="text-xs font-medium text-accent bg-accent/10 px-2 py-1 rounded-full"
                      >
                        {metric}
                      </span>
                    ))}
                  </div>
                </CardContent>
                <CardFooter className="pt-0 gap-3">
                  <Button
                    variant="outline"
                    size="sm"
                    className="flex-1"
                    asChild
                  >
                    <a
                      href={project.demoUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                    >
                      <ExternalLink className="h-4 w-4 mr-2" />
                      Live Demo
                    </a>
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="flex-1"
                    asChild
                  >
                    <a
                      href={project.githubUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                    >
                      <Github className="h-4 w-4 mr-2" />
                      Code
                    </a>
                  </Button>
                </CardFooter>
              </Card>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  )
}
