"use client"

import { motion } from "framer-motion"
import { Briefcase } from "lucide-react"

const experiences = [
  {
    title: "Lead Developer",
    company: "Freelance",
    period: "2022 - Present",
    achievements: [
      "Architected and delivered 10+ production applications serving thousands of users",
      "Reduced API response time by 40% through query optimization and caching strategies",
      "Mentored junior developers and established code review best practices",
    ],
  },
  {
    title: "Software Development Intern",
    company: "Alyah Software Internship Program",
    period: "2021 - 2022",
    achievements: [
      "Developed responsive web applications using React and Node.js",
      "Collaborated with cross-functional teams to deliver features on schedule",
    ],
  },
]

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.2,
    },
  },
}

const itemVariants = {
  hidden: { opacity: 0, x: -20 },
  visible: { opacity: 1, x: 0 },
}

export function ExperienceSection() {
  return (
    <section id="experience" className="py-20 sm:py-24">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl sm:text-4xl font-bold text-foreground mb-4">
            Experience
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            My professional journey building impactful software solutions.
          </p>
        </motion.div>

        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          className="max-w-3xl mx-auto space-y-8"
        >
          {experiences.map((exp, index) => (
            <motion.div
              key={exp.title + exp.company}
              variants={itemVariants}
              className="relative pl-8 border-l-2 border-border hover:border-accent transition-colors"
            >
              <div className="absolute -left-3 top-0 w-6 h-6 bg-background border-2 border-accent rounded-full flex items-center justify-center">
                <Briefcase className="w-3 h-3 text-accent" />
              </div>
              <div className="bg-card rounded-lg p-6 border border-border hover:border-accent/30 transition-colors">
                <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-4">
                  <div>
                    <h3 className="text-lg font-semibold text-foreground">
                      {exp.title}
                    </h3>
                    <p className="text-accent">{exp.company}</p>
                  </div>
                  <span className="text-sm text-muted-foreground mt-1 sm:mt-0">
                    {exp.period}
                  </span>
                </div>
                <ul className="space-y-2">
                  {exp.achievements.map((achievement, i) => (
                    <li
                      key={i}
                      className="text-sm text-muted-foreground flex items-start"
                    >
                      <span className="w-1.5 h-1.5 bg-accent rounded-full mt-2 mr-3 flex-shrink-0" />
                      {achievement}
                    </li>
                  ))}
                </ul>
              </div>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  )
}
