"use client"

import { motion } from "framer-motion"

const skillCategories = [
  {
    category: "Frontend",
    skills: [
      { name: "React", level: "Expert" },
      { name: "Next.js", level: "Expert" },
      { name: "TypeScript", level: "Expert" },
      { name: "Tailwind CSS", level: "Expert" },
      { name: "HTML/CSS", level: "Expert" },
    ],
  },
  {
    category: "Backend",
    skills: [
      { name: "Node.js", level: "Expert" },
      { name: "Python", level: "Advanced" },
      { name: "REST APIs", level: "Expert" },
      { name: "WebSockets", level: "Advanced" },
      { name: "GraphQL", level: "Intermediate" },
    ],
  },
  {
    category: "Database",
    skills: [
      { name: "PostgreSQL", level: "Expert" },
      { name: "Prisma ORM", level: "Expert" },
      { name: "MongoDB", level: "Advanced" },
      { name: "Redis", level: "Intermediate" },
    ],
  },
  {
    category: "DevOps",
    skills: [
      { name: "Docker", level: "Advanced" },
      { name: "Git", level: "Expert" },
      { name: "CI/CD", level: "Advanced" },
      { name: "Vercel", level: "Expert" },
      { name: "AWS", level: "Intermediate" },
    ],
  },
]

const levelDots: Record<string, number> = {
  Expert: 4,
  Advanced: 3,
  Intermediate: 2,
}

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1,
    },
  },
}

const itemVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: { opacity: 1, y: 0 },
}

export function SkillsSection() {
  return (
    <section id="skills" className="py-20 sm:py-24 bg-secondary/30">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl sm:text-4xl font-bold text-foreground mb-4">
            Skills & Tools
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Proficiency levels across different areas of software development.
          </p>
        </motion.div>

        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8"
        >
          {skillCategories.map((category) => (
            <motion.div
              key={category.category}
              variants={itemVariants}
              className="bg-card rounded-lg p-6 border border-border"
            >
              <h3 className="text-lg font-semibold text-foreground mb-4 pb-2 border-b border-border">
                {category.category}
              </h3>
              <div className="space-y-3">
                {category.skills.map((skill) => (
                  <div
                    key={skill.name}
                    className="flex items-center justify-between"
                  >
                    <span className="text-sm text-muted-foreground">
                      {skill.name}
                    </span>
                    <div className="flex gap-1">
                      {[1, 2, 3, 4].map((dot) => (
                        <span
                          key={dot}
                          className={`w-2 h-2 rounded-full ${
                            dot <= levelDots[skill.level]
                              ? "bg-accent"
                              : "bg-border"
                          }`}
                        />
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </motion.div>
          ))}
        </motion.div>

        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ delay: 0.5 }}
          className="flex justify-center gap-8 mt-8 text-sm text-muted-foreground"
        >
          <span className="flex items-center gap-2">
            <span className="flex gap-1">
              {[1, 2, 3, 4].map((d) => (
                <span key={d} className="w-2 h-2 rounded-full bg-accent" />
              ))}
            </span>
            Expert
          </span>
          <span className="flex items-center gap-2">
            <span className="flex gap-1">
              {[1, 2, 3].map((d) => (
                <span key={d} className="w-2 h-2 rounded-full bg-accent" />
              ))}
              <span className="w-2 h-2 rounded-full bg-border" />
            </span>
            Advanced
          </span>
          <span className="flex items-center gap-2">
            <span className="flex gap-1">
              {[1, 2].map((d) => (
                <span key={d} className="w-2 h-2 rounded-full bg-accent" />
              ))}
              {[3, 4].map((d) => (
                <span key={d} className="w-2 h-2 rounded-full bg-border" />
              ))}
            </span>
            Intermediate
          </span>
        </motion.div>
      </div>
    </section>
  )
}
