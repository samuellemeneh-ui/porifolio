"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { Mail, Github, Linkedin, Twitter, Copy, Check } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useToast } from "@/hooks/use-toast"

const socialLinks = [
  {
    name: "GitHub",
    icon: Github,
    href: "https://github.com/samuelemenehui",
    username: "samuelemenehui",
  },
  {
    name: "LinkedIn",
    icon: Linkedin,
    href: "https://linkedin.com/in/samuel-lemeneh",
    username: "samuel-lemeneh",
  },
  {
    name: "Twitter/X",
    icon: Twitter,
    href: "https://twitter.com/samuellemeneh",
    username: "@samuellemeneh",
  },
]

export function ContactSection() {
  const [copied, setCopied] = useState(false)
  const { toast } = useToast()

  const email = "samuellemeneh@gmail.com"

  const copyEmail = async () => {
    try {
      await navigator.clipboard.writeText(email)
      setCopied(true)
      toast({
        title: "Email copied!",
        description: "Email address has been copied to your clipboard.",
      })
      setTimeout(() => setCopied(false), 2000)
    } catch {
      toast({
        title: "Failed to copy",
        description: "Please copy the email manually.",
        variant: "destructive",
      })
    }
  }

  return (
    <section id="contact" className="py-20 sm:py-24">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="text-center mb-12"
        >
          <h2 className="text-3xl sm:text-4xl font-bold text-foreground mb-4">
            Get in Touch
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            If you would like to discuss a project or just say hi, I&apos;m always
            down to chat.
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.2 }}
          className="max-w-xl mx-auto"
        >
          {/* Email */}
          <div className="bg-card rounded-lg p-6 border border-border mb-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-accent/10 flex items-center justify-center">
                  <Mail className="w-5 h-5 text-accent" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Email</p>
                  <p className="font-medium text-foreground">{email}</p>
                </div>
              </div>
              <Button
                variant="ghost"
                size="icon"
                onClick={copyEmail}
                className="hover:bg-accent/10"
                aria-label="Copy email"
              >
                {copied ? (
                  <Check className="w-4 h-4 text-accent" />
                ) : (
                  <Copy className="w-4 h-4" />
                )}
              </Button>
            </div>
          </div>

          {/* Social Links */}
          <div className="grid grid-cols-3 gap-4 mb-8">
            {socialLinks.map((link) => (
              <a
                key={link.name}
                href={link.href}
                target="_blank"
                rel="noopener noreferrer"
                className="bg-card rounded-lg p-4 border border-border hover:border-accent/50 transition-all duration-200 hover:scale-[1.02] text-center group"
              >
                <link.icon className="w-6 h-6 mx-auto mb-2 text-muted-foreground group-hover:text-accent transition-colors" />
                <p className="text-sm font-medium text-foreground">
                  {link.name}
                </p>
              </a>
            ))}
          </div>

          {/* Terminal command */}
          <motion.div
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ delay: 0.4 }}
            className="bg-foreground dark:bg-card rounded-lg p-4 font-mono text-sm"
          >
            <div className="flex items-center gap-2 text-background dark:text-muted-foreground">
              <span className="text-accent">$</span>
              <span>npx contact samuel-lemeneh</span>
            </div>
          </motion.div>
        </motion.div>
      </div>
    </section>
  )
}
